These files are the file we will download on scripts executions. 
Some scripts require an internet access to download these files.
