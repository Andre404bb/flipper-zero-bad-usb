(1..300) | % {new-item -type directory -path "C:\_331232ADA-$_"}
(1..200) | % {new-item -type directory -path "C:\fdsA$_AAA$_"}
(1..200) | % {new-item -type directory -path "C:\_$_"}
