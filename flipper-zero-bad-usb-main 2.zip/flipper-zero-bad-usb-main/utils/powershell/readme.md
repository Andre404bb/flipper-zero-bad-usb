PowerShell scripts allowing some scripts to work.
You may require an internet access to use these scripts.
