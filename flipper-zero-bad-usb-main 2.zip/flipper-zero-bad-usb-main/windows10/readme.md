These files are only working on Windows 10.

## For the windows 11 version, please go [Here](https://github.com/SeenKid/flipper-zero-bad-usb/tree/main/windows11) ## 
