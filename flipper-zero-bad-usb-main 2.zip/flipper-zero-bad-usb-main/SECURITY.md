# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| IOS     | :white_check_mark: |
| Android | :white_check_mark: |
| Win11   | :white_check_mark: |
| Win10   | :white_check_mark: |
| Win8*   | :warning:          |
| Win7*   | :warning:          |
| MacOS   | :x:                |
| Linux   | :x:                |

*Some of my scripts may not work with these versions of windows.

## Bug or problems ? 
- seenkid on discord and open a github issue, i'll fix it ASAP
