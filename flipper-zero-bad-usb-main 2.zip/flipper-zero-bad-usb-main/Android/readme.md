## Due to some compatibility issues between phones using Android, please note that some of these scripts may not work on some devices.
