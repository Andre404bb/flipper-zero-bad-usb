
<div align="center">
  <h1><code>Flipper Zero: BadUSB Scripts</code></h1>
  <p>
    <strong>My scripts for the Flipper Zero BadUSB</strong> <br/>
    WARNING : SOME SCRIPTS MAY NOT WORK ON SLOW COMPUTERS ! (You can add more delay to make them work) <br/>
    EDIT : Thanks everyone for downloading my scripts ! <strong>Don't forget to star the project <3 </strong><br/>
    If you feel like to, follow me on github and explore my github repositories ! <br/><br/>
    <a href="https://visitorbadge.io/status?path=https%3A%2F%2Fgithub.com%2FSeenKid%2Fflipper-zero-bad-usb"><img src="https://api.visitorbadge.io/api/visitors?path=https%3A%2F%2Fgithub.com%2FSeenKid%2Fflipper-zero-bad-usb&label=Views&labelColor=%23ff8a65&countColor=%23f47373" /></a>
  </p>
</div>

<img src="https://github.com/SeenKid/flipper-zero-bad-usb/blob/74e6f916bd71bdd2c597bbf4a6af268f3f95fc2a/utils/imgs/Z7KSHodItHk5UKKCgmWdP_badusb1.png" height="380" width="1050" >


## Requirements ##
- Flipper Zero
- Internet connection

## Installation ##
- Download the repo [HERE](https://github.com/SeenKid/flipper-zero-bad-usb/releases/latest)
- drag&drop repo files in qflipper (SD Card/badusb)
- You are ready :)

## Sponsoring
If you would like to help me ~~dealing with my sushis addiction~~ **making this project even greater**, feel free to sponsor me. All sponsors buttons are on the right.

## Informations ##
![GitHub all releases](https://img.shields.io/github/downloads/SeenKid/flipper-zero-bad-usb/total?logo=GitHub) 
![GitHub commit activity](https://img.shields.io/github/commit-activity/w/SeenKid/flipper-zero-bad-usb) 
![GitHub repo size](https://img.shields.io/github/repo-size/SeenKid/flipper-zero-bad-usb) 
![GitHub release (release)](https://img.shields.io/github/v/release/SeenKid/flipper-zero-bad-usb?include_prereleases)
[![Donate](https://img.shields.io/badge/Donate-PayPal-green.svg)](https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=yann.berlemont@protonmail.ch&lc=US&no_note=0&item_name=Thank+you+for+suppporting+SeenKid's+Github+Project.&cn=&curency_code=EUR&bn=PP-DonationsBF:btn_donateCC_LG.gif:NonHosted)

## Usage Agreement ##

By downloading and using the scripts provided, you are automatically agreeing to the following usage agreement. If you do not agree, please, refrain from downloading or use the scripts.

1. You acknowledge that SeenKid ``is NOT responsible`` for your actions or any damage you may cause as a result of using the scripts.
2. You are ``permitted`` to share all of the files.
3. You are ``allowed`` to modify the files, but are still responsible for your own actions.
4. If you are using my scripts in your own repo, please consider giving credits.
5. Please, check the license file

## Contact ##
- seenkid on discord

## Credits ## 
- [UNC0V3R3D](https://github.com/UNC0V3R3D)
