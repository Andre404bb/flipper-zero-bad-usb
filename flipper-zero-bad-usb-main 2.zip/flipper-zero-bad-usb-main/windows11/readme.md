For windows 11, command prompts can take more time to open than on windows 10. So I made these scripts working for windows 11 aswell.

Windows 10 version [Here](https://github.com/SeenKid/flipper-zero-bad-usb/tree/main/windows10)
